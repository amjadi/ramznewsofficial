/**
 * RamzNews Gen 2 - Main Entry Point
 * 
 * This file serves as the main router for the Cloudflare Worker,
 * handling different types of requests and scheduled events.
 */

import { fetchFeeds } from './fetchFeeds.js';
import { formatWithAI } from './aiFormatter.js';
import { sendToTelegram } from './sendTelegram.js';
import { CONFIG } from './config.js';

/**
 * Main worker event handler
 */
export default {
  // Handle all incoming HTTP requests
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const path = url.pathname;

    // Admin dashboard or health check endpoints can be added here
    if (path === '/health') {
      return new Response(JSON.stringify({ 
        status: 'ok',
        version: '1.0.0',
        timestamp: new Date().toISOString()
      }), {
        headers: { 'Content-Type': 'application/json' }
      });
    }

    // Default response
    return new Response('RamzNews Gen 2 is running!', {
      headers: { 'Content-Type': 'text/plain' }
    });
  },

  // Handle scheduled events (cron triggers)
  async scheduled(event, env, ctx) {
    try {
      console.log(`Scheduled worker triggered at ${new Date().toISOString()}`);
      
      // Determine which cron job is running based on cron expression
      const cronExpression = event.cron;
      
      if (cronExpression === '*/10 * * * *') {
        // Every 10 minutes: Fetch RSS feeds
        await fetchFeeds(env);
      } else {
        // Every minute: Process queue and send to Telegram
        
        // Step 1: Get pending items from the queue
        const pendingItems = await getPendingItems(env);
        
        for (const item of pendingItems) {
          try {
            // Step 2: Format with AI
            const formattedPost = await formatWithAI(item, env);
            
            // Step 3: Send to Telegram
            if (formattedPost) {
              await sendToTelegram(formattedPost, env);
            }
          } catch (itemError) {
            console.error(`Error processing item: ${JSON.stringify(item)}`, itemError);
          }
        }
      }
      
      return new Response('Scheduled task completed');
    } catch (error) {
      console.error('Error in scheduled event:', error);
      return new Response('Error in scheduled task', { status: 500 });
    }
  }
};

/**
 * Get pending items from the queue for processing
 */
async function getPendingItems(env) {
  try {
    // Get queue key from config
    const queueKey = CONFIG.STORAGE.QUEUE_KEY;
    const queueData = await env.POST_TRACKER.get(queueKey, { type: 'json' });
    
    if (!queueData || !Array.isArray(queueData.items) || queueData.items.length === 0) {
      return [];
    }
    
    // Get items for processing (limited by batch size from config)
    const batchSize = CONFIG.PROCESSING.BATCH_SIZE;
    const itemsToProcess = queueData.items.slice(0, batchSize);
    
    // Update the queue by removing the items we're processing
    await env.POST_TRACKER.put(
      queueKey, 
      JSON.stringify({ 
        items: queueData.items.slice(batchSize),
        lastUpdated: new Date().toISOString()
      })
    );
    
    return itemsToProcess;
  } catch (error) {
    console.error('Error getting pending items:', error);
    return [];
  }
} 