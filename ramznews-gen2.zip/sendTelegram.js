/**
 * sendTelegram.js - Telegram Message Sender for RamzNews Gen 2
 * 
 * This module is responsible for:
 * 1. Taking formatted posts
 * 2. Sending them to the Telegram channel
 * 3. Handling media attachments
 * 4. Tracking sent posts to avoid duplicates
 */

import { CONFIG } from './config.js';

// Telegram API Base URL
const TELEGRAM_API_BASE = 'https://api.telegram.org/bot';

/**
 * Send a formatted post to Telegram
 */
export async function sendToTelegram(post, env) {
  try {
    console.log(`Sending post to Telegram: ${post.id}`);
    
    // Get Telegram settings from config
    const botToken = CONFIG.TELEGRAM.BOT_TOKEN;
    const channelUsername = CONFIG.TELEGRAM.CHANNEL_USERNAME;
    
    // Check if this post has already been sent
    const sentKey = `${CONFIG.STORAGE.SENT_KEY_PREFIX}${post.id}`;
    const alreadySent = await env.POST_TRACKER.get(sentKey);
    
    if (alreadySent) {
      console.log(`Post ${post.id} already sent, skipping`);
      return { success: false, reason: 'already_sent' };
    }
    
    // Set up the message parameters
    let params = {
      chat_id: channelUsername,
      parse_mode: 'HTML',
      disable_web_page_preview: true, // We'll send our own image if available
    };
    
    // Decide whether to send image with caption or just text
    if (post.image_url) {
      // Try to send as photo with caption
      try {
        const result = await sendWithImage(botToken, params, post);
        
        // Mark as sent
        await env.POST_TRACKER.put(sentKey, JSON.stringify({
          sent_at: new Date().toISOString(),
          message_id: result.message_id
        }), {
          expirationTtl: CONFIG.STORAGE.TTL_SECONDS
        });
        
        return { success: true, message_id: result.message_id, type: 'photo' };
      } catch (imageError) {
        console.warn('Failed to send with image, falling back to text only:', imageError);
        // Fall back to text-only
      }
    }
    
    // Send as text-only message
    params.text = post.telegram_text;
    const result = await sendTelegramRequest(botToken, 'sendMessage', params);
    
    // Mark as sent
    await env.POST_TRACKER.put(sentKey, JSON.stringify({
      sent_at: new Date().toISOString(),
      message_id: result.message_id
    }), {
      expirationTtl: CONFIG.STORAGE.TTL_SECONDS
    });
    
    return { success: true, message_id: result.message_id, type: 'text' };
  } catch (error) {
    console.error(`Error sending post ${post.id} to Telegram:`, error);
    throw error;
  }
}

/**
 * Send a post with an image and caption
 */
async function sendWithImage(botToken, params, post) {
  try {
    // Check if the text is too long for a caption (Telegram limit is 1024 chars)
    if (post.telegram_text.length > 1024) {
      // For long text, we send the image first, then the text as a separate message
      
      // 1. Send the image without caption
      const photoParams = {
        ...params,
        photo: post.image_url,
        // No caption for now
      };
      
      const photoResult = await sendTelegramRequest(botToken, 'sendPhoto', photoParams);
      
      // 2. Send the text as a reply to the photo
      const textParams = {
        ...params,
        text: post.telegram_text,
        reply_to_message_id: photoResult.message_id
      };
      
      await sendTelegramRequest(botToken, 'sendMessage', textParams);
      
      // Return the photo message ID
      return photoResult;
    } else {
      // If text is short enough, send as single message with caption
      const photoParams = {
        ...params,
        photo: post.image_url,
        caption: post.telegram_text
      };
      
      return await sendTelegramRequest(botToken, 'sendPhoto', photoParams);
    }
  } catch (error) {
    console.error('Error sending with image:', error);
    throw error;
  }
}

/**
 * Send a request to the Telegram API
 */
async function sendTelegramRequest(botToken, method, params) {
  try {
    const url = `${TELEGRAM_API_BASE}${botToken}/${method}`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(params)
    });
    
    const result = await response.json();
    
    if (!result.ok) {
      throw new Error(`Telegram API error: ${JSON.stringify(result)}`);
    }
    
    return result.result;
  } catch (error) {
    console.error(`Error calling Telegram API ${method}:`, error);
    throw error;
  }
} 