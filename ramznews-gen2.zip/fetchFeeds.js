/**
 * fetchFeeds.js - RSS Feed Fetcher for RamzNews Gen 2
 * 
 * This module is responsible for:
 * 1. Fetching RSS feeds from configured sources
 * 2. Parsing the feeds (both RSS and Atom formats)
 * 3. Extracting key information
 * 4. Storing the items in a queue for processing
 */

import { generatePostIdentifier } from './shared/identifier.js';
import { sanitizeHtml } from './shared/sanitize.js';
import { CONFIG } from './config.js';

/**
 * Main function to fetch all configured RSS feeds
 */
export async function fetchFeeds(env) {
  try {
    console.log('Starting feed fetch process');
    
    // Get feed URLs from config
    const feedUrls = CONFIG.RSS_FEEDS;
    
    console.log(`Processing ${feedUrls.length} feeds`);
    
    // Process each feed in parallel
    const results = await Promise.allSettled(
      feedUrls.map(url => processFeed(url, env))
    );
    
    // Count successful and failed feeds
    const successful = results.filter(r => r.status === 'fulfilled').length;
    const failed = results.filter(r => r.status === 'rejected').length;
    
    console.log(`Feed processing complete. Success: ${successful}, Failed: ${failed}`);
    
    return { successful, failed };
  } catch (error) {
    console.error('Error in fetchFeeds:', error);
    throw error;
  }
}

/**
 * Process a single RSS feed
 */
async function processFeed(feedUrl, env) {
  try {
    console.log(`Fetching feed: ${feedUrl}`);
    
    // Fetch the feed
    const response = await fetch(feedUrl, {
      headers: {
        'User-Agent': 'RamzNews-Bot/2.0',
        'Accept': 'application/rss+xml, application/atom+xml, application/xml, text/xml'
      },
      cf: {
        cacheTtl: 300, // Cache for 5 minutes
        cacheEverything: true
      }
    });
    
    if (!response.ok) {
      throw new Error(`Failed to fetch feed: ${response.status} ${response.statusText}`);
    }
    
    const text = await response.text();
    
    // Parse the XML feed
    const parser = new DOMParser();
    const doc = parser.parseFromString(text, 'application/xml');
    
    // Determine feed type (RSS or Atom)
    const feedType = doc.querySelector('rss') ? 'rss' : 'atom';
    console.log(`Feed type detected: ${feedType}`);
    
    // Extract items based on feed type
    const items = feedType === 'rss' 
      ? extractRssItems(doc, feedUrl)
      : extractAtomItems(doc, feedUrl);
    
    console.log(`Extracted ${items.length} items from feed`);
    
    // Filter out items we've already processed
    const newItems = await filterNewItems(items, env);
    console.log(`${newItems.length} new items to queue`);
    
    // Add new items to the processing queue
    if (newItems.length > 0) {
      await addItemsToQueue(newItems, env);
    }
    
    return { processed: items.length, new: newItems.length };
  } catch (error) {
    console.error(`Error processing feed ${feedUrl}:`, error);
    throw error;
  }
}

/**
 * Extract items from RSS format feeds
 */
function extractRssItems(doc, feedUrl) {
  try {
    const source = doc.querySelector('channel > title')?.textContent || new URL(feedUrl).hostname;
    const items = Array.from(doc.querySelectorAll('item'));
    
    return items.map(item => {
      // Get basic elements
      const title = item.querySelector('title')?.textContent || '';
      const link = item.querySelector('link')?.textContent || '';
      const description = item.querySelector('description')?.textContent || '';
      const pubDate = item.querySelector('pubDate')?.textContent || '';
      
      // Clean the description HTML
      const cleanDescription = sanitizeHtml(description);
      
      // Generate a unique identifier for this item
      const id = generatePostIdentifier(title, link);
      
      return {
        id,
        title,
        link,
        description: cleanDescription,
        pubDate,
        source,
        timestamp: new Date().toISOString(),
        feedType: 'rss'
      };
    });
  } catch (error) {
    console.error('Error extracting RSS items:', error);
    return [];
  }
}

/**
 * Extract items from Atom format feeds
 */
function extractAtomItems(doc, feedUrl) {
  try {
    const source = doc.querySelector('feed > title')?.textContent || new URL(feedUrl).hostname;
    const items = Array.from(doc.querySelectorAll('entry'));
    
    return items.map(item => {
      // Get basic elements
      const title = item.querySelector('title')?.textContent || '';
      const link = item.querySelector('link[rel="alternate"]')?.getAttribute('href') || 
                  item.querySelector('link')?.getAttribute('href') || '';
      const content = item.querySelector('content')?.textContent || 
                    item.querySelector('summary')?.textContent || '';
      const published = item.querySelector('published')?.textContent || 
                      item.querySelector('updated')?.textContent || '';
      
      // Clean the content HTML
      const cleanContent = sanitizeHtml(content);
      
      // Generate a unique identifier for this item
      const id = generatePostIdentifier(title, link);
      
      return {
        id,
        title,
        link,
        description: cleanContent,
        pubDate: published,
        source,
        timestamp: new Date().toISOString(),
        feedType: 'atom'
      };
    });
  } catch (error) {
    console.error('Error extracting Atom items:', error);
    return [];
  }
}

/**
 * Filter out items that have already been processed
 */
async function filterNewItems(items, env) {
  const newItems = [];
  
  for (const item of items) {
    const itemKey = `${CONFIG.STORAGE.ITEM_KEY_PREFIX}${item.id}`;
    const exists = await env.POST_TRACKER.get(itemKey);
    
    if (!exists) {
      newItems.push(item);
    }
  }
  
  return newItems;
}

/**
 * Add new items to the processing queue
 */
async function addItemsToQueue(newItems, env) {
  try {
    // Get the current queue
    const queueKey = CONFIG.STORAGE.QUEUE_KEY;
    const currentQueue = await env.POST_TRACKER.get(queueKey, { type: 'json' }) || { items: [] };
    
    // Add new items to the queue
    const updatedQueue = {
      items: [...currentQueue.items, ...newItems],
      lastUpdated: new Date().toISOString()
    };
    
    // Save the updated queue
    await env.POST_TRACKER.put(queueKey, JSON.stringify(updatedQueue));
    
    // Also mark each item as seen to avoid re-processing
    for (const item of newItems) {
      const itemKey = `${CONFIG.STORAGE.ITEM_KEY_PREFIX}${item.id}`;
      await env.POST_TRACKER.put(itemKey, 'seen', {
        expirationTtl: CONFIG.STORAGE.TTL_SECONDS
      });
    }
    
    return true;
  } catch (error) {
    console.error('Error adding items to queue:', error);
    throw error;
  }
} 