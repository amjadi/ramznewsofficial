/**
 * aiFormatter.js - AI-based Content Formatter for RamzNews Gen 2
 * 
 * This module is responsible for:
 * 1. Taking raw RSS feed items
 * 2. Using LLM to format them into engaging Telegram posts
 * 3. Extracting images from article URLs
 * 4. Generating appropriate hashtags
 * 5. Creating the final formatted post
 */

import { categorizeContent } from './shared/category.js';
import { CONFIG } from './config.js';

/**
 * Format a news item with AI for Telegram posting
 */
export async function formatWithAI(item, env) {
  try {
    console.log(`Formatting item: ${item.title}`);
    
    // Process with LLM to get formatted text
    const formattedText = await processWithLLM(item, env);
    
    // Extract image URL from the original article
    const imageUrl = await extractImageUrl(item.link);
    
    // Create the final formatted post
    const post = {
      id: item.id,
      title: item.title,
      telegram_text: formattedText,
      image_url: imageUrl,
      source: item.source,
      original_link: item.link,
      processed_at: new Date().toISOString()
    };
    
    console.log(`Successfully formatted item: ${item.id}`);
    return post;
  } catch (error) {
    console.error(`Error formatting item ${item.id}:`, error);
    throw error;
  }
}

/**
 * Process an item with the Language Model
 */
async function processWithLLM(item, env) {
  try {
    // Get API key and settings from config
    const apiKey = CONFIG.AI.OPENROUTER_API_KEY;
    const apiUrl = CONFIG.AI.API_URL;
    const model = CONFIG.AI.MODEL;
    const temperature = CONFIG.AI.TEMPERATURE;
    const maxTokens = CONFIG.AI.MAX_TOKENS;
    
    // Get prompt template from config
    const promptTemplate = CONFIG.DEFAULT_PROMPT_TEMPLATE;
    
    // Fill in the prompt template with item data
    const prompt = promptTemplate
      .replace('{title}', item.title)
      .replace('{description}', item.description);
    
    // Make the API request to OpenRouter
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'HTTP-Referer': 'https://ramznews.telegram.bot'
      },
      body: JSON.stringify({
        model: model,
        messages: [
          {
            role: 'system',
            content: 'تو یک متخصص خلاصه‌سازی و فرمت‌دهی اخبار به فرمت پست‌های تلگرامی هستی. لطفاً با رعایت قوانین فرمت، یک پست تمیز، خلاصه و حرفه‌ای تولید کن.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        temperature: temperature,
        max_tokens: maxTokens
      })
    });
    
    if (!response.ok) {
      const error = await response.json();
      throw new Error(`OpenRouter API error: ${JSON.stringify(error)}`);
    }
    
    const result = await response.json();
    
    // Extract the content from the response
    const content = result.choices[0]?.message?.content;
    
    if (!content) {
      throw new Error('No content returned from OpenRouter');
    }
    
    // Clean up any extra formatting or markers
    return cleanupFormattedText(content);
  } catch (error) {
    console.error('Error processing with LLM:', error);
    throw error;
  }
}

/**
 * Clean up the formatted text from LLM
 */
function cleanupFormattedText(text) {
  // Remove any potential code block markers
  let cleaned = text.replace(/```/g, '');
  
  // Ensure proper HTML tag formatting for Telegram
  cleaned = cleaned.replace(/<b>/g, '<b>').replace(/<\/b>/g, '</b>');
  
  // Remove any accidental markdown formatting that might have been added
  cleaned = cleaned.replace(/\*\*(.*?)\*\*/g, '<b>$1</b>');
  
  // Ensure bullet points are consistent
  cleaned = cleaned.replace(/•/g, '•');
  cleaned = cleaned.replace(/\*/g, '•');
  cleaned = cleaned.replace(/- /g, '• ');
  
  // Ensure double newlines between sections
  cleaned = cleaned.replace(/\n\n\n+/g, '\n\n');
  
  return cleaned.trim();
}

/**
 * Extract an image URL from the article
 */
async function extractImageUrl(articleUrl) {
  try {
    console.log(`Extracting image from: ${articleUrl}`);
    
    // Fetch the article HTML
    const response = await fetch(articleUrl, {
      headers: {
        'User-Agent': 'RamzNews-Bot/2.0'
      },
      cf: {
        cacheTtl: 3600, // Cache for 1 hour
        cacheEverything: true
      }
    });
    
    if (!response.ok) {
      console.warn(`Failed to fetch article: ${response.status}`);
      return null;
    }
    
    const html = await response.text();
    
    // Create a simple parser for the HTML
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');
    
    // Try to find the image in this order of preference:
    // 1. Open Graph image
    let imageUrl = doc.querySelector('meta[property="og:image"]')?.getAttribute('content');
    
    // 2. Twitter image
    if (!imageUrl) {
      imageUrl = doc.querySelector('meta[name="twitter:image"]')?.getAttribute('content');
    }
    
    // 3. First large image in the article
    if (!imageUrl) {
      const images = Array.from(doc.querySelectorAll('img'));
      
      // Filter for potentially featured images
      const potentialImages = images.filter(img => {
        const src = img.getAttribute('src');
        const width = parseInt(img.getAttribute('width') || '0');
        const height = parseInt(img.getAttribute('height') || '0');
        const className = img.getAttribute('class') || '';
        
        // Check for featured image class names
        const isFeatured = className.includes('featured') || 
                         className.includes('main') || 
                         className.includes('hero');
        
        // Check for reasonable dimensions
        const hasGoodSize = (width >= 300 && height >= 200) || isFeatured;
        
        // Check for common thumbnail patterns to exclude
        const notThumbnail = !src.includes('thumb') && !src.includes('icon') && !src.includes('avatar');
        
        return src && hasGoodSize && notThumbnail;
      });
      
      if (potentialImages.length > 0) {
        imageUrl = potentialImages[0].getAttribute('src');
      }
    }
    
    // Ensure the URL is absolute
    if (imageUrl && !imageUrl.startsWith('http')) {
      const url = new URL(articleUrl);
      if (imageUrl.startsWith('//')) {
        imageUrl = `https:${imageUrl}`;
      } else if (imageUrl.startsWith('/')) {
        imageUrl = `${url.protocol}//${url.host}${imageUrl}`;
      } else {
        imageUrl = `${url.protocol}//${url.host}/${imageUrl}`;
      }
    }
    
    console.log(`Image extraction result: ${imageUrl || 'No image found'}`);
    return imageUrl;
  } catch (error) {
    console.error(`Error extracting image from ${articleUrl}:`, error);
    return null;
  }
} 