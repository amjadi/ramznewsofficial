/**
 * config.js - تنظیمات و مقادیر ثابت پروژه رمزنیوز نسل ۲
 * 
 * این فایل شامل تمام مقادیر ثابت و تنظیمات مورد نیاز پروژه است
 * به جای استفاده از متغیرهای محیطی، مقادیر به صورت مستقیم در کد قرار گرفته‌اند
 */

export const CONFIG = {
  // تنظیمات تلگرام
  TELEGRAM: {
    BOT_TOKEN: "7901847454:AAHiID4x5SDdZCNbwgYd3vVLmRnKVl10J78",
    CHANNEL_USERNAME: "@ramznewsofficial",
    SIGNATURE: "@ramznewsofficial | اخبار رمزی"
  },

  // تنظیمات OpenRouter و هوش مصنوعی
  AI: {
    OPENROUTER_API_KEY: "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",
    API_URL: "https://openrouter.ai/api/v1/chat/completions",
    MODEL: "mistralai/mixtral-8x7b",
    TEMPERATURE: 0.3,
    MAX_TOKENS: 500
  },

  // منابع RSS
  RSS_FEEDS: [
    // منابع خبری
    "https://www.bbc.com/persian/iran/rss.xml",
    "https://rss.dw.com/rdf/rss-per-iran",
    "https://per.euronews.com/rss",
    // منابع رمزارز
    "https://ramzarz.news/feed/",
    "https://arzdigital.com/feed/"
  ],

  // تنظیمات ذخیره‌سازی و کش
  STORAGE: {
    // کلید پیش‌فرض برای صف پردازش
    QUEUE_KEY: "feed_queue",
    
    // پیشوند کلید برای موارد ارسال شده
    SENT_KEY_PREFIX: "sent:",
    
    // پیشوند کلید برای آیتم‌های دیده شده
    ITEM_KEY_PREFIX: "item:",
    
    // مدت زمان نگهداری آیتم‌ها (30 روز به ثانیه)
    TTL_SECONDS: 30 * 24 * 60 * 60
  },

  // تنظیمات پردازش
  PROCESSING: {
    // حداکثر تعداد آیتم‌های پردازش شده در هر اجرا
    BATCH_SIZE: 5,
    
    // فعال بودن حالت دیباگ
    DEBUG_MODE: false
  },
  
  // پرامپت پیش‌فرض برای هوش مصنوعی
  DEFAULT_PROMPT_TEMPLATE: `
یک خبر فارسی شامل عنوان و متن دارم. لطفاً آن را به یک پست تلگرامی خلاصه و زیبا تبدیل کن:
- حداکثر ۵ خط
- دارای لحن حرفه‌ای و خبری
- موبایل‌پسند، دارای ایموجی مرتبط در ابتدای عنوان
- عنوان باید با تگ <b> بولد شود
- متن اصلی به‌صورت بولت لیست (•) باشد
- هشتگ‌های فارسی مرتبط (حداکثر ۵ تا) در انتها اضافه کن
- هیچ لینک یا منبع خارجی نباید در پست باشد
- فقط فارسی بنویس، بدون جداول، تبلیغ یا جمله ناقص

ورودی:
عنوان: {title}
متن: {description}

خروجی فقط متن نهایی پست تلگرام باشد. در انتها خط زیر را اضافه کن:
@ramznewsofficial | اخبار رمزی
`
}; 